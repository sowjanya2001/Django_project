from django.contrib import admin
#from app.models import Register
#from app.models import Diary
# Register your models here.
#admin.site.register(Register)
#admin.site.register(Diary)
