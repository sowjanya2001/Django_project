# Create your views here.
from django.shortcuts import render,redirect
#from app.forms import RegisterForm
from django.contrib.auth import authenticate,login,logout
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.contrib.auth.decorators import login_required
#from app.models import Register
from app.models import Diary
from django.template import RequestContext
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .forms import CustomUserCreationForm

def home(req):
	return render(req,'app/home.html')

'''def signup(req):
	registered = False
	if req.method=="POST":
		form=RegisterForm(req.POST)
		if form.is_valid():
			form.save()
			registered = True
			return render(req, 'app/home.html',{'form':form,'registered':registered})
		else:
			print(form.errors)
	else:
		form = RegisterForm()
	return render(req,'app/signup.html',{'form':form,'registered':registered})

def logout(request):
    return render(request, 'app/home.html')

def login(request):
	if request.method == 'POST':
		username = request.POST.get('mail')
		password = request.POST.get('password')
		user = authenticate(request, mail=username, password=password)
		a = Register.objects.filter(mail=username).exists()
		b = Register.objects.filter(password=password).exists()
		if not request.user.is_authenticated:
			return render(request,'app/mydiary.html')
		else:
			print("Someone tried to Login and failed.")
			print("They used username: {} and password: {}".format(username,password))
			return HttpResponse("Invalid login details given")
	else:
		return render(request,'app/login.html')'''

def signup(request):
	if request.method == "POST":
		form = CustomUserCreationForm(request.POST)
		if form.is_valid():
			form.save()
			return redirect('home')
	else:
		form = CustomUserCreationForm()
	return render(request,'registration/signup.html',{'form':form})



def change(req):
	if req.method == "POST":
		oldp = req.POST['oldpassword']
		newp = req.POST['newpassword']
		conp = req.POST['confirmpassword']
		data = Register.objects.get(password=oldp)
		if newp != conp:
			return HttpResponse("password Does not match")
		else:
			data.password = conp
			data.status=1
			data.save()
			return HttpResponse("password updated")
	return render(req,'app/change.html')

def add(request):
	return render(request,'app/adddiary.html')

def mydiary(request):
	if request.method=="POST":
		cont = request.POST['comment']
		print(request.user.id)
		obj = Diary(content = cont,user_id = request.user.id)
		obj.save()
		return render(request,'app/mydiary.html')
	return render(request,'app/mydiary.html')

def display(request):
	if request.user.is_authenticated:
		print('WELCOME')
		print(request.user.id)
		data = Diary.objects.filter(user_id=request.user.id)
		return render(request,'app/display.html',{'data':data})
	return render(request,'app/display.html')