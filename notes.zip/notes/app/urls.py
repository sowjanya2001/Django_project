from django.urls import path,include
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
	path('',views.home,name="home"),
    path('sign_up/',views.sign_up,name="sign-up"),
    path('accounts/', include('django.contrib.auth.urls')),
    path('app/add/',views.add,name="add"),
    path('app/mydiary/',views.mydiary,name="mydiary"),
    path('app/display/',views.display,name="display"),
]


'''<div style="margin-left: 15%;margin-top: 20px" class="vertical-center">
		<textarea rows="15" cols="150" name="comment"></textarea><br><br><br>
	<button style="margin-left:40%;margin-right:auto">Save</button>'''

